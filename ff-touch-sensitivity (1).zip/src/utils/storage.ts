import { SensitivitySettings, Profile } from '../types';

const SETTINGS_KEY = 'ff_touch_sensitivity_settings_v1';
const PROFILES_KEY = 'ff_touch_sensitivity_profiles_v1';

export const DEFAULT_SETTINGS: SensitivitySettings = {
  horizontalSensitivity: 100,
  verticalSensitivity: 100,
  enabled: false,
  selectedProfileId: null,
  overlayEnabled: false,
  hapticEnabled: true,
  soundEnabled: true,
  startOnBoot: false,
  rememberLastProfile: true,
  theme: 'dark',
  syncAxes: false,
};

export const INITIAL_PROFILES: Profile[] = [
  {
    id: 'p-1',
    name: 'My Settings',
    horizontalSensitivity: 140,
    verticalSensitivity: 90,
    createdAt: Date.now() - 3600000 * 24,
  },
  {
    id: 'p-2',
    name: 'Fast Aim',
    horizontalSensitivity: 160,
    verticalSensitivity: 110,
    createdAt: Date.now() - 3600000 * 12,
  },
  {
    id: 'p-3',
    name: 'Precision',
    horizontalSensitivity: 100,
    verticalSensitivity: 80,
    createdAt: Date.now() - 3600000 * 2,
  },
];

export function loadSettings(): SensitivitySettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: SensitivitySettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadProfiles(): Profile[] {
  try {
    const raw = localStorage.getItem(PROFILES_KEY);
    if (!raw) return INITIAL_PROFILES;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_PROFILES;
  } catch {
    return INITIAL_PROFILES;
  }
}

export function saveProfiles(profiles: Profile[]): void {
  try {
    localStorage.setItem(PROFILES_KEY, JSON.stringify(profiles));
  } catch {
    // Ignore
  }
}
