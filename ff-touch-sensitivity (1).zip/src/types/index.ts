export interface SensitivitySettings {
  horizontalSensitivity: number; // 0 to 200
  verticalSensitivity: number;   // 0 to 200
  enabled: boolean;
  selectedProfileId: string | null;
  overlayEnabled: boolean;
  hapticEnabled: boolean;
  soundEnabled: boolean;
  startOnBoot: boolean;
  rememberLastProfile: boolean;
  theme: 'dark' | 'oled' | 'cyberpunk';
  syncAxes: boolean;
}

export interface Preset {
  id: string;
  name: string;
  horizontalSensitivity: number;
  verticalSensitivity: number;
  description: string;
  tag: string;
  recommendedFor: string;
}

export interface Profile {
  id: string;
  name: string;
  horizontalSensitivity: number;
  verticalSensitivity: number;
  createdAt: number;
}

export interface TouchPoint {
  x: number;
  y: number;
  rawX: number;
  rawY: number;
  adjustedX: number;
  adjustedY: number;
  timestamp: number;
  force?: number;
}

export interface PermissionState {
  accessibilityGranted: boolean;
  overlayGranted: boolean;
}

export type ActiveTab = 'main' | 'test' | 'presets' | 'profiles' | 'overlay' | 'settings' | 'export';
