import React, { useState, useEffect } from 'react';
import { SensitivitySettings, Profile, Preset, ActiveTab } from './types';
import { loadSettings, saveSettings, loadProfiles, saveProfiles, DEFAULT_SETTINGS } from './utils/storage';
import { Header } from './components/Header';
import { MainController } from './components/MainController';
import { TouchTestCanvas } from './components/TouchTestCanvas';
import { PresetsSection } from './components/PresetsSection';
import { ProfilesSection } from './components/ProfilesSection';
import { FloatingOverlaySimulator } from './components/FloatingOverlaySimulator';
import { SettingsScreen } from './components/SettingsScreen';
import { AndroidExporter } from './components/AndroidExporter';
import { ResetConfirmModal } from './components/ResetConfirmModal';
import { PermissionModal } from './components/PermissionModal';
import { SafetyNoticeBanner } from './components/SafetyNoticeBanner';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('main');
  const [settings, setSettings] = useState<SensitivitySettings>(loadSettings);
  const [profiles, setProfiles] = useState<Profile[]>(loadProfiles);
  const [showResetModal, setShowResetModal] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);

  // Save settings whenever changed
  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  // Save profiles whenever changed
  useEffect(() => {
    saveProfiles(profiles);
  }, [profiles]);

  // Sensitivity Handlers
  const handleUpdateHorizontal = (val: number) => {
    setSettings((prev) => ({
      ...prev,
      horizontalSensitivity: Math.max(0, Math.min(200, val)),
    }));
  };

  const handleUpdateVertical = (val: number) => {
    setSettings((prev) => ({
      ...prev,
      verticalSensitivity: Math.max(0, Math.min(200, val)),
    }));
  };

  const handleApplySettings = () => {
    setSettings((prev) => ({
      ...prev,
      enabled: true,
    }));
  };

  const handleToggleController = (enabled: boolean) => {
    setSettings((prev) => ({
      ...prev,
      enabled,
    }));
  };

  const handleToggleOverlay = (overlayEnabled: boolean) => {
    setSettings((prev) => ({
      ...prev,
      overlayEnabled,
    }));
  };

  const handleSelectPreset = (preset: Preset) => {
    setSettings((prev) => ({
      ...prev,
      horizontalSensitivity: preset.horizontalSensitivity,
      verticalSensitivity: preset.verticalSensitivity,
    }));
  };

  // Profile Actions
  const handleSaveProfile = (name: string) => {
    const newProfile: Profile = {
      id: `p-${Date.now()}`,
      name,
      horizontalSensitivity: settings.horizontalSensitivity,
      verticalSensitivity: settings.verticalSensitivity,
      createdAt: Date.now(),
    };
    setProfiles((prev) => [newProfile, ...prev]);
  };

  const handleDeleteProfile = (id: string) => {
    setProfiles((prev) => prev.filter((p) => p.id !== id));
  };

  const handleLoadProfile = (profile: Profile) => {
    setSettings((prev) => ({
      ...prev,
      horizontalSensitivity: profile.horizontalSensitivity,
      verticalSensitivity: profile.verticalSensitivity,
      selectedProfileId: profile.id,
    }));
  };

  // Reset Handler
  const handleConfirmReset = () => {
    setSettings((prev) => ({
      ...prev,
      horizontalSensitivity: 100,
      verticalSensitivity: 100,
    }));
    setShowResetModal(false);
  };

  // Theme styling background class
  const getThemeClass = () => {
    if (settings.theme === 'oled') return 'bg-black text-slate-100 min-h-screen';
    if (settings.theme === 'cyberpunk') return 'bg-slate-950 text-cyan-50 min-h-screen';
    return 'bg-[#0B0F19] text-slate-100 min-h-screen';
  };

  return (
    <div className={`${getThemeClass()} font-sans selection:bg-cyan-500 selection:text-slate-950 antialiased pb-12`}>
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        settings={settings}
      />

      {/* Main Content Area */}
      <main className="max-w-4xl mx-auto px-4 pt-6 space-y-6">
        {activeTab === 'main' && (
          <MainController
            settings={settings}
            onUpdateHorizontal={handleUpdateHorizontal}
            onUpdateVertical={handleUpdateVertical}
            onApplySettings={handleApplySettings}
            onToggleController={handleToggleController}
            onSelectPreset={handleSelectPreset}
            onOpenResetModal={() => setShowResetModal(true)}
            onOpenTouchTest={() => setActiveTab('test')}
            onOpenPermissionModal={() => setShowPermissionModal(true)}
          />
        )}

        {activeTab === 'test' && (
          <TouchTestCanvas settings={settings} />
        )}

        {activeTab === 'presets' && (
          <PresetsSection
            settings={settings}
            onSelectPreset={handleSelectPreset}
            onNavigateToMain={() => setActiveTab('main')}
          />
        )}

        {activeTab === 'profiles' && (
          <ProfilesSection
            settings={settings}
            profiles={profiles}
            onSaveProfile={handleSaveProfile}
            onDeleteProfile={handleDeleteProfile}
            onLoadProfile={handleLoadProfile}
          />
        )}

        {activeTab === 'overlay' && (
          <FloatingOverlaySimulator
            settings={settings}
            onUpdateHorizontal={handleUpdateHorizontal}
            onUpdateVertical={handleUpdateVertical}
            onApplySettings={handleApplySettings}
            onToggleOverlay={handleToggleOverlay}
            onOpenPermissionModal={() => setShowPermissionModal(true)}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsScreen
            settings={settings}
            onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
            onOpenPermissionModal={() => setShowPermissionModal(true)}
          />
        )}

        {activeTab === 'export' && (
          <AndroidExporter />
        )}

        {/* Global Safety Statement Footer */}
        <SafetyNoticeBanner />
      </main>

      {/* Modals */}
      <ResetConfirmModal
        isOpen={showResetModal}
        onConfirm={handleConfirmReset}
        onCancel={() => setShowResetModal(false)}
      />

      <PermissionModal
        isOpen={showPermissionModal}
        onClose={() => setShowPermissionModal(false)}
        onGrantPermission={() => {
          handleToggleOverlay(true);
          setShowPermissionModal(false);
        }}
        overlayGranted={settings.overlayEnabled}
      />
    </div>
  );
}
