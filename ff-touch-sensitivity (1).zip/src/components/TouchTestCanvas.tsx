import React, { useRef, useState, useEffect } from 'react';
import { SensitivitySettings, TouchPoint } from '../types';
import { sounds } from '../utils/audio';
import { Trash2, RefreshCw, Crosshair, Sparkles, Activity, Layers, CheckCircle } from 'lucide-react';

interface TouchTestCanvasProps {
  settings: SensitivitySettings;
}

export const TouchTestCanvas: React.FC<TouchTestCanvasProps> = ({ settings }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [points, setPoints] = useState<TouchPoint[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [stats, setStats] = useState({
    rawDistance: 0,
    adjustedDistance: 0,
    peakVelocity: 0,
    pointCount: 0,
  });
  const [showRawGhost, setShowRawGhost] = useState(true);

  // Clear Canvas handler
  const handleClear = () => {
    setPoints([]);
    setStats({
      rawDistance: 0,
      adjustedDistance: 0,
      peakVelocity: 0,
      pointCount: 0,
    });
    sounds.playClick(settings.soundEnabled);
  };

  // Draw loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Canvas size
    const width = canvas.width;
    const height = canvas.height;

    // Clear background
    ctx.fillStyle = '#0B0F19';
    ctx.fillRect(0, 0, width, height);

    // Draw Cyberpunk Grid
    ctx.strokeStyle = '#1E293B';
    ctx.lineWidth = 1;
    const gridSize = 30;

    for (let x = 0; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw Center Crosshair
    ctx.strokeStyle = '#334155';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(width / 2, 0);
    ctx.lineTo(width / 2, height);
    ctx.moveTo(0, height / 2);
    ctx.lineTo(width, height / 2);
    ctx.stroke();
    ctx.setLineDash([]);

    if (points.length < 2) {
      // Helper text if empty
      ctx.fillStyle = '#64748B';
      ctx.font = '13px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('Move finger / mouse inside canvas to test response', width / 2, height / 2 - 10);
      ctx.fillText(`Horizontal: ${Math.round(settings.horizontalSensitivity)}% | Vertical: ${Math.round(settings.verticalSensitivity)}%`, width / 2, height / 2 + 15);
      return;
    }

    // 1. Draw Raw Finger Path (Ghost Line)
    if (showRawGhost) {
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.25)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(points[0].rawX, points[0].rawY);

      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].rawX, points[i].rawY);
      }
      ctx.stroke();
    }

    // 2. Draw Adjusted Touch Trajectory Path (Bright Neon Line)
    ctx.strokeStyle = '#06B6D4';
    ctx.lineWidth = 3;
    ctx.shadowColor = '#06B6D4';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.moveTo(points[0].adjustedX, points[0].adjustedY);

    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].adjustedX, points[i].adjustedY);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;

    // 3. Draw Waypoint Nodes / Vector Connectors (Prompt requirement: ●─────── ╲ ╲ ●)
    points.forEach((pt, idx) => {
      if (idx % 3 === 0 || idx === points.length - 1) {
        // Node dot
        ctx.fillStyle = idx === points.length - 1 ? '#34D399' : '#06B6D4';
        ctx.beginPath();
        ctx.arc(pt.adjustedX, pt.adjustedY, idx === points.length - 1 ? 6 : 4, 0, Math.PI * 2);
        ctx.fill();

        // Direction connector to raw
        if (showRawGhost) {
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.2)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(pt.rawX, pt.rawY);
          ctx.lineTo(pt.adjustedX, pt.adjustedY);
          ctx.stroke();
        }
      }
    });

    // 4. Draw Current Pointer Target Pulse
    const last = points[points.length - 1];
    ctx.strokeStyle = '#34D399';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(last.adjustedX, last.adjustedY, 12, 0, Math.PI * 2);
    ctx.stroke();

  }, [points, settings, showRawGhost]);

  // Touch & Mouse Event Handlers
  const handleStart = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;

    const rawX = clientX - rect.left;
    const rawY = clientY - rect.top;

    setIsDrawing(true);
    setPoints([
      {
        x: rawX,
        y: rawY,
        rawX,
        rawY,
        adjustedX: rawX,
        adjustedY: rawY,
        timestamp: Date.now(),
      },
    ]);
  };

  const handleMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();

    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;

    const currentRawX = clientX - rect.left;
    const currentRawY = clientY - rect.top;

    setPoints((prev) => {
      if (prev.length === 0) return prev;
      const lastPoint = prev[prev.length - 1];

      // Delta algorithm
      const deltaX = currentRawX - lastPoint.rawX;
      const deltaY = currentRawY - lastPoint.rawY;

      // Adjusted deltas based on sensitivity multipliers
      const adjX = deltaX * (settings.horizontalSensitivity / 100);
      const adjY = deltaY * (settings.verticalSensitivity / 100);

      const nextAdjustedX = lastPoint.adjustedX + adjX;
      const nextAdjustedY = lastPoint.adjustedY + adjY;

      // Stats accumulation
      const segRawDist = Math.hypot(deltaX, deltaY);
      const segAdjDist = Math.hypot(adjX, adjY);

      setStats((s) => ({
        rawDistance: Math.round(s.rawDistance + segRawDist),
        adjustedDistance: Math.round(s.adjustedDistance + segAdjDist),
        peakVelocity: Math.max(s.peakVelocity, Math.round(segAdjDist)),
        pointCount: prev.length + 1,
      }));

      return [
        ...prev,
        {
          x: currentRawX,
          y: currentRawY,
          rawX: currentRawX,
          rawY: currentRawY,
          adjustedX: nextAdjustedX,
          adjustedY: nextAdjustedY,
          timestamp: Date.now(),
        },
      ];
    });
  };

  const handleEnd = () => {
    setIsDrawing(false);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Readout Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white uppercase font-mono">Touch Trajectory Test</h3>
            <p className="text-xs text-slate-400">
              Real-time velocity & trajectory physics simulator
            </p>
          </div>
        </div>

        {/* Live Sensitivity Indicators */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end font-mono">
          <div className="px-3 py-1.5 bg-slate-800 rounded-xl border border-cyan-500/30 text-xs">
            <span className="text-slate-400 mr-1">X Sensitivity:</span>
            <span className="text-cyan-400 font-bold">{Math.round(settings.horizontalSensitivity)}%</span>
          </div>
          <div className="px-3 py-1.5 bg-slate-800 rounded-xl border border-cyan-500/30 text-xs">
            <span className="text-slate-400 mr-1">Y Sensitivity:</span>
            <span className="text-cyan-400 font-bold">{Math.round(settings.verticalSensitivity)}%</span>
          </div>
        </div>
      </div>

      {/* Canvas Drawing Surface */}
      <div className="relative bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        {/* Top Controls Overlay */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10 pointer-events-none">
          <div className="pointer-events-auto flex items-center gap-2">
            <button
              onClick={() => setShowRawGhost(!showRawGhost)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium border backdrop-blur-md transition-all flex items-center gap-1.5 ${
                showRawGhost
                  ? 'bg-slate-900/90 border-slate-700 text-slate-300'
                  : 'bg-slate-900/50 border-slate-800 text-slate-500'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{showRawGhost ? 'Raw Ghost Path: ON' : 'Raw Ghost Path: OFF'}</span>
            </button>
          </div>

          <button
            onClick={handleClear}
            className="pointer-events-auto px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-rose-950/60 text-rose-400 border border-slate-700 hover:border-rose-700 text-xs font-mono font-bold transition-all shadow-lg flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>
        </div>

        {/* Responsive HTML5 Canvas */}
        <canvas
          ref={canvasRef}
          width={700}
          height={380}
          onMouseDown={handleStart}
          onMouseMove={handleMove}
          onMouseUp={handleEnd}
          onMouseLeave={handleEnd}
          onTouchStart={handleStart}
          onTouchMove={handleMove}
          onTouchEnd={handleEnd}
          className="w-full h-[320px] sm:h-[380px] cursor-crosshair touch-none bg-slate-950"
        />

        {/* Bottom Legend Overlay */}
        <div className="bg-slate-900/95 border-t border-slate-800 p-3 px-4 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-slate-400">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400" />
              <span>Adjusted Trajectory</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500/50" />
              <span>Raw Touch Path</span>
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span>Points: <strong className="text-white">{stats.pointCount}</strong></span>
            <span>Raw Dist: <strong className="text-white">{stats.rawDistance}px</strong></span>
            <span>Adjusted Dist: <strong className="text-cyan-400">{stats.adjustedDistance}px</strong></span>
          </div>
        </div>
      </div>

      {/* Touch Physics Explanation Box */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 text-xs space-y-2">
        <h4 className="font-bold text-white flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>Touch Processing Algorithm</span>
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-400 font-mono text-[11px]">
          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
            <p className="text-cyan-400 font-bold mb-1">X-Axis Delta Formula:</p>
            <p>DeltaX = CurrentX - PreviousX</p>
            <p>AdjustedX = DeltaX × ({settings.horizontalSensitivity / 100})</p>
          </div>
          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
            <p className="text-cyan-400 font-bold mb-1">Y-Axis Delta Formula:</p>
            <p>DeltaY = CurrentY - PreviousY</p>
            <p>AdjustedY = DeltaY × ({settings.verticalSensitivity / 100})</p>
          </div>
        </div>
      </div>
    </div>
  );
};
