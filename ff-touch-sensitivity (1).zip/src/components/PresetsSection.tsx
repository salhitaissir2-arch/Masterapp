import React from 'react';
import { SensitivitySettings, Preset } from '../types';
import { QUICK_PRESETS } from '../data/presets';
import { sounds } from '../utils/audio';
import { Zap, CheckCircle2, Sliders, Target, Shield, Gauge } from 'lucide-react';

interface PresetsSectionProps {
  settings: SensitivitySettings;
  onSelectPreset: (preset: Preset) => void;
  onNavigateToMain: () => void;
}

export const PresetsSection: React.FC<PresetsSectionProps> = ({
  settings,
  onSelectPreset,
  onNavigateToMain,
}) => {
  const handleSelect = (preset: Preset) => {
    onSelectPreset(preset);
    sounds.playClick(settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white uppercase font-mono">Quick Presets</h2>
            <p className="text-xs text-slate-400">
              Select pre-tuned sensitivity ratios optimized for different playstyles
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {QUICK_PRESETS.map((preset) => {
          const isActive =
            Math.round(settings.horizontalSensitivity) === preset.horizontalSensitivity &&
            Math.round(settings.verticalSensitivity) === preset.verticalSensitivity;

          return (
            <div
              key={preset.id}
              onClick={() => handleSelect(preset)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer relative overflow-hidden group ${
                isActive
                  ? 'bg-slate-900 border-cyan-500 ring-2 ring-cyan-500/30 shadow-xl shadow-cyan-500/10'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                    {preset.tag}
                  </span>
                  <h3 className="text-base font-bold text-white font-mono">{preset.name}</h3>
                </div>

                {isActive && (
                  <div className="flex items-center gap-1 text-xs font-bold text-cyan-400 font-mono bg-cyan-500/10 px-2.5 py-1 rounded-full border border-cyan-500/30">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Selected</span>
                  </div>
                )}
              </div>

              <p className="text-xs text-slate-400 mb-4">{preset.description}</p>

              <div className="grid grid-cols-2 gap-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800 font-mono text-xs">
                <div>
                  <span className="text-slate-500 block text-[10px]">HORIZONTAL</span>
                  <span className="text-sm font-bold text-cyan-400">{preset.horizontalSensitivity}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">VERTICAL</span>
                  <span className="text-sm font-bold text-cyan-400">{preset.verticalSensitivity}%</span>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
                <span>Best for: <strong className="text-slate-300 font-normal">{preset.recommendedFor}</strong></span>
                <span className="text-cyan-400 font-bold group-hover:translate-x-1 transition-transform">
                  Apply Ratio →
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-center pt-2">
        <button
          onClick={onNavigateToMain}
          className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 font-mono font-bold text-xs border border-slate-700 transition-all shadow-md inline-flex items-center gap-2"
        >
          <Sliders className="w-4 h-4" />
          <span>BACK TO CUSTOM SLIDERS</span>
        </button>
      </div>
    </div>
  );
};
