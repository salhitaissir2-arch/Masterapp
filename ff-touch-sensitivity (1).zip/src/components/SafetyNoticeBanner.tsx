import React from 'react';
import { ShieldCheck, Lock, CheckCircle2, AlertCircle } from 'lucide-react';

export const SafetyNoticeBanner: React.FC = () => {
  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 text-xs space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-emerald-400 font-bold font-mono">
          <ShieldCheck className="w-4 h-4" />
          <span>100% Anti-Cheat Safe & Legal Guarantee</span>
        </div>
        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          Fair Play
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-slate-400 font-mono text-[11px]">
        <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 flex items-start gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-white font-bold block mb-0.5">No File Modification</span>
            <span>Does NOT edit Free Fire APK files or game configs.</span>
          </div>
        </div>

        <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 flex items-start gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-white font-bold block mb-0.5">No Memory Injection</span>
            <span>Zero RAM editing, DLL injection, or process hooking.</span>
          </div>
        </div>

        <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 flex items-start gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <span className="text-white font-bold block mb-0.5">Official Android APIs</span>
            <span>Uses standard Jetpack Compose & Overlay APIs safely.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
