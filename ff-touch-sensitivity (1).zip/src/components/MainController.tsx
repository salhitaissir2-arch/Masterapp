import React, { useState } from 'react';
import { SensitivitySettings, Preset } from '../types';
import { QUICK_PRESETS } from '../data/presets';
import { sounds } from '../utils/audio';
import { Sliders, RotateCcw, CheckCircle2, ShieldCheck, Zap, Activity, Info, Lock, Unlock, ToggleLeft, ToggleRight } from 'lucide-react';

interface MainControllerProps {
  settings: SensitivitySettings;
  onUpdateHorizontal: (val: number) => void;
  onUpdateVertical: (val: number) => void;
  onApplySettings: () => void;
  onToggleController: (enabled: boolean) => void;
  onSelectPreset: (preset: Preset) => void;
  onOpenResetModal: () => void;
  onOpenTouchTest: () => void;
  onOpenPermissionModal: () => void;
}

export const MainController: React.FC<MainControllerProps> = ({
  settings,
  onUpdateHorizontal,
  onUpdateVertical,
  onApplySettings,
  onToggleController,
  onSelectPreset,
  onOpenResetModal,
  onOpenTouchTest,
  onOpenPermissionModal,
}) => {
  const [syncAxes, setSyncAxes] = useState(settings.syncAxes || false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleHorizontalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    onUpdateHorizontal(val);
    sounds.playSlider(300 + val * 2, settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);

    if (syncAxes) {
      onUpdateVertical(val);
    }
  };

  const handleVerticalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    onUpdateVertical(val);
    sounds.playSlider(300 + val * 2, settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);

    if (syncAxes) {
      onUpdateHorizontal(val);
    }
  };

  const handleApply = () => {
    onApplySettings();
    sounds.playSuccess(settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);
    setToastMessage('Settings Applied');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handlePresetClick = (preset: Preset) => {
    onSelectPreset(preset);
    sounds.playClick(settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);
  };

  const handleToggleClick = () => {
    const nextState = !settings.enabled;
    if (nextState && !settings.overlayEnabled) {
      onOpenPermissionModal();
    } else {
      onToggleController(nextState);
      sounds.playClick(settings.soundEnabled);
      sounds.triggerHaptic(settings.hapticEnabled);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-cyan-500 text-slate-950 px-4 py-3 rounded-xl font-bold shadow-2xl flex items-center gap-2 border border-cyan-300 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-slate-950" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hero Banner Header */}
      <div className="text-center space-y-2 py-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/80 text-xs text-cyan-400 font-mono mb-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>100% Fair Play & Anti-Cheat Compliant</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight uppercase font-mono">
          FF TOUCH <span className="text-cyan-400">SENSITIVITY</span>
        </h2>
        <p className="text-sm text-slate-400 max-w-lg mx-auto">
          Customize your touch response for a smoother gaming experience.
        </p>
      </div>

      {/* Controller Toggle Card */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${settings.enabled ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`} />
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                Sensitivity Controller
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                  settings.enabled ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
                }`}>
                  {settings.enabled ? 'Controller Active' : 'Controller Disabled'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {settings.enabled ? 'Active touch processing engine enabled' : 'Toggle ON to enable background sensitivity tuning'}
              </p>
            </div>
          </div>

          <button
            onClick={handleToggleClick}
            className={`p-1.5 rounded-full transition-all ${
              settings.enabled ? 'text-emerald-400 hover:text-emerald-300' : 'text-slate-500 hover:text-slate-400'
            }`}
            title="Toggle Controller"
          >
            {settings.enabled ? (
              <ToggleRight className="w-10 h-10 text-emerald-400" />
            ) : (
              <ToggleLeft className="w-10 h-10 text-slate-600" />
            )}
          </button>
        </div>
      </div>

      {/* Independent Tuning Lock Indicator */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span className="flex items-center gap-1">
          <Info className="w-3.5 h-3.5 text-cyan-400" />
          <span>Horizontal & Vertical sliders operate independently</span>
        </span>
        <button
          onClick={() => {
            setSyncAxes(!syncAxes);
            sounds.playClick(settings.soundEnabled);
          }}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-md border transition-all text-xs ${
            syncAxes
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-400 font-semibold'
              : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-300'
          }`}
        >
          {syncAxes ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
          <span>{syncAxes ? 'Axes Locked (Sync)' : 'Independent Axes'}</span>
        </button>
      </div>

      {/* Sliders Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Horizontal Sensitivity Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 hover:border-slate-700 transition-all shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full blur-2xl group-hover:bg-cyan-500/10 transition-all pointer-events-none" />
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold font-mono">
                X
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Horizontal Sensitivity</h3>
                <p className="text-[11px] text-slate-400">Controls horizontal swipe velocity</p>
              </div>
            </div>
            <div className="px-3 py-1 bg-slate-800 border border-cyan-500/30 rounded-xl">
              <span className="text-lg font-black font-mono text-cyan-400">
                {Math.round(settings.horizontalSensitivity)}%
              </span>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <input
              type="range"
              min="0"
              max="200"
              value={settings.horizontalSensitivity}
              onChange={handleHorizontalChange}
              className="w-full h-3 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/40"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-500">
              <span>0%</span>
              <span className="text-slate-400 font-semibold">100% (Default)</span>
              <span>200%</span>
            </div>
          </div>
        </div>

        {/* Vertical Sensitivity Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 hover:border-slate-700 transition-all shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full blur-2xl group-hover:bg-cyan-500/10 transition-all pointer-events-none" />
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold font-mono">
                Y
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Vertical Sensitivity</h3>
                <p className="text-[11px] text-slate-400">Controls vertical drag/recoil response</p>
              </div>
            </div>
            <div className="px-3 py-1 bg-slate-800 border border-cyan-500/30 rounded-xl">
              <span className="text-lg font-black font-mono text-cyan-400">
                {Math.round(settings.verticalSensitivity)}%
              </span>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <input
              type="range"
              min="0"
              max="200"
              value={settings.verticalSensitivity}
              onChange={handleVerticalChange}
              className="w-full h-3 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/40"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-500">
              <span>0%</span>
              <span className="text-slate-400 font-semibold">100% (Default)</span>
              <span>200%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Presets Section */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>Quick Presets</span>
          </h3>
          <span className="text-xs text-slate-400">Instant Tuning Profiles</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {QUICK_PRESETS.slice(0, 4).map((preset) => {
            const isSelected =
              Math.round(settings.horizontalSensitivity) === preset.horizontalSensitivity &&
              Math.round(settings.verticalSensitivity) === preset.verticalSensitivity;

            return (
              <button
                key={preset.id}
                onClick={() => handlePresetClick(preset)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-cyan-500/10 border-cyan-500 text-white shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-500'
                    : 'bg-slate-800/60 border-slate-700/80 text-slate-300 hover:border-slate-600 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold font-mono">{preset.name}</span>
                  {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                </div>
                <div className="text-[10px] font-mono text-slate-400 space-y-0.5">
                  <p>H: <span className="text-cyan-400 font-semibold">{preset.horizontalSensitivity}%</span></p>
                  <p>V: <span className="text-cyan-400 font-semibold">{preset.verticalSensitivity}%</span></p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Touch Test Banner Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900/90 to-cyan-950/40 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
            <Activity className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Interactive Touch Test</h3>
            <p className="text-xs text-slate-400">
              Draw on the canvas to test live trajectory with current <span className="text-cyan-400 font-mono">X:{Math.round(settings.horizontalSensitivity)}%</span> and <span className="text-cyan-400 font-mono">Y:{Math.round(settings.verticalSensitivity)}%</span>.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenTouchTest}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-cyan-400 font-bold text-xs font-mono transition-all whitespace-nowrap flex items-center justify-center gap-2"
        >
          <span>OPEN TOUCH TEST</span>
          <Activity className="w-4 h-4" />
        </button>
      </div>

      {/* Main Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
        <button
          onClick={onOpenResetModal}
          className="w-full sm:w-1/3 py-3.5 px-4 rounded-xl bg-slate-900 hover:bg-rose-950/40 text-rose-400 border border-rose-900/40 hover:border-rose-700 font-bold text-xs uppercase font-mono tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg"
        >
          <RotateCcw className="w-4 h-4" />
          <span>RESET</span>
        </button>

        <button
          onClick={handleApply}
          className="w-full sm:w-2/3 py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-black text-sm uppercase font-mono tracking-wider transition-all shadow-xl shadow-cyan-500/20 active:scale-[0.99] flex items-center justify-center gap-2"
        >
          <Sliders className="w-4 h-4" />
          <span>APPLY SETTINGS</span>
        </button>
      </div>
    </div>
  );
};
