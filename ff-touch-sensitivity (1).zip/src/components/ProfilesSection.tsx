import React, { useState } from 'react';
import { SensitivitySettings, Profile } from '../types';
import { sounds } from '../utils/audio';
import { Bookmark, Plus, Trash2, Check, Download, Layers, Sparkles, FolderPlus } from 'lucide-react';

interface ProfilesSectionProps {
  settings: SensitivitySettings;
  profiles: Profile[];
  onSaveProfile: (name: string) => void;
  onDeleteProfile: (id: string) => void;
  onLoadProfile: (profile: Profile) => void;
}

export const ProfilesSection: React.FC<ProfilesSectionProps> = ({
  settings,
  profiles,
  onSaveProfile,
  onDeleteProfile,
  onLoadProfile,
}) => {
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [profileName, setProfileName] = useState('');

  const handleSaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim()) return;
    onSaveProfile(profileName.trim());
    sounds.playSuccess(settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);
    setProfileName('');
    setShowSaveModal(false);
  };

  const handleLoad = (profile: Profile) => {
    onLoadProfile(profile);
    sounds.playClick(settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onDeleteProfile(id);
    sounds.playClick(settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Bookmark className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white uppercase font-mono">Sensitivity Profiles</h2>
            <p className="text-xs text-slate-400">
              Save, load, and manage custom sensitivity profiles saved in DataStore
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowSaveModal(true)}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs font-mono transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
        >
          <FolderPlus className="w-4 h-4" />
          <span>SAVE CURRENT PROFILE</span>
        </button>
      </div>

      {/* Profiles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {profiles.map((profile) => {
          const isCurrent =
            Math.round(settings.horizontalSensitivity) === Math.round(profile.horizontalSensitivity) &&
            Math.round(settings.verticalSensitivity) === Math.round(profile.verticalSensitivity);

          return (
            <div
              key={profile.id}
              onClick={() => handleLoad(profile)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer relative ${
                isCurrent
                  ? 'bg-slate-900 border-cyan-500 ring-2 ring-cyan-500/30 shadow-xl'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Bookmark className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-base font-bold text-white font-mono">{profile.name}</h3>
                </div>

                <div className="flex items-center gap-2">
                  {isCurrent && (
                    <span className="text-[10px] font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20 font-mono">
                      LOADED
                    </span>
                  )}
                  <button
                    onClick={(e) => handleDelete(profile.id, e)}
                    className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-rose-950/80 text-slate-400 hover:text-rose-400 border border-slate-700 hover:border-rose-800 transition-all"
                    title="Delete Profile"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800/80 font-mono text-xs">
                <div>
                  <span className="text-slate-500 block text-[10px]">HORIZONTAL</span>
                  <span className="text-sm font-bold text-cyan-400">
                    {Math.round(profile.horizontalSensitivity)}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">VERTICAL</span>
                  <span className="text-sm font-bold text-cyan-400">
                    {Math.round(profile.verticalSensitivity)}%
                  </span>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
                <span>Saved locally in DataStore</span>
                <span className="text-cyan-400 font-bold font-mono">Click to Load →</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Save Profile Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-scale-up">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                <Bookmark className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-mono">Save Sensitivity Profile</h3>
                <p className="text-xs text-slate-400">Store current slider values as a named preset</p>
              </div>
            </div>

            <form onSubmit={handleSaveSubmit} className="space-y-4 pt-2">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <span className="text-slate-500">Horizontal:</span>
                  <span className="text-cyan-400 font-bold ml-1">{Math.round(settings.horizontalSensitivity)}%</span>
                </div>
                <div>
                  <span className="text-slate-500">Vertical:</span>
                  <span className="text-cyan-400 font-bold ml-1">{Math.round(settings.verticalSensitivity)}%</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1.5">PROFILE NAME</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. My Fast Aim Setup"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowSaveModal(false)}
                  className="w-1/2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-bold"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono text-xs font-bold shadow-lg shadow-cyan-500/20"
                >
                  SAVE PROFILE
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
