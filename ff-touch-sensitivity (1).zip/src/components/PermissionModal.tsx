import React from 'react';
import { Shield, Layers, ExternalLink, X, CheckCircle2 } from 'lucide-react';

interface PermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGrantPermission: () => void;
  overlayGranted: boolean;
}

export const PermissionModal: React.FC<PermissionModalProps> = ({
  isOpen,
  onClose,
  onGrantPermission,
  overlayGranted,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-scale-up relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white font-mono">Permission Required</h3>
            <p className="text-xs text-slate-400">Display Over Other Apps (Overlay)</p>
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-2 font-mono">
          <p className="leading-relaxed">
            To show the quick sensitivity controller widget over Free Fire while playing, Android requires the <strong>Display Over Other Apps</strong> permission.
          </p>
          <ul className="list-disc list-inside text-slate-400 space-y-1 pt-1">
            <li>Does NOT access game memory or files</li>
            <li>Can be hidden or toggled OFF at any time</li>
            <li>100% compliant with Android Safety Guidelines</li>
          </ul>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
          <button
            onClick={onClose}
            className="w-full sm:w-1/2 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-bold"
          >
            NOT NOW
          </button>
          <button
            onClick={onGrantPermission}
            className="w-full sm:w-1/2 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono text-xs font-bold shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2"
          >
            <ExternalLink className="w-4 h-4" />
            <span>OPEN SETTINGS</span>
          </button>
        </div>
      </div>
    </div>
  );
};
