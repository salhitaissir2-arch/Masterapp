import React, { useState } from 'react';
import { KOTLIN_PROJECT_FILES, KotlinFile } from '../data/kotlinFiles';
import JSZip from 'jszip';
import { Code, Download, Copy, Check, FileCode, Smartphone, Terminal, FolderArchive, Sparkles, FileText, ExternalLink, HelpCircle } from 'lucide-react';

export const AndroidExporter: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<KotlinFile>(KOTLIN_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [allCopied, setAllCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [downloadSuccessMessage, setDownloadSuccessMessage] = useState<string | null>(null);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyAllProjectCode = () => {
    let combined = `=====================================================\n`;
    combined += `FF TOUCH SENSITIVITY - ALL KOTLIN / GRADLE / XML FILES\n`;
    combined += `=====================================================\n\n`;

    KOTLIN_PROJECT_FILES.forEach((f) => {
      combined += `-----------------------------------------------------\n`;
      combined += `FILE: ${f.path}\n`;
      combined += `-----------------------------------------------------\n\n`;
      combined += f.content + `\n\n`;
    });

    navigator.clipboard.writeText(combined);
    setAllCopied(true);
    setTimeout(() => setAllCopied(false), 2500);
  };

  const triggerDataDownload = (dataUrl: string, filename: string) => {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
    }, 100);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    setDownloadSuccessMessage(null);
    try {
      const zip = new JSZip();

      KOTLIN_PROJECT_FILES.forEach((file) => {
        zip.file(file.path, file.content);
      });

      // Generate base64 data URI to bypass blob restrictions in sandboxed iframe previews
      const base64 = await zip.generateAsync({ type: 'base64' });
      const dataUrl = `data:application/zip;base64,${base64}`;

      triggerDataDownload(dataUrl, 'FFTouchSensitivity_AndroidStudioProject.zip');
      setDownloadSuccessMessage('تم بدء تنزيل ملف ZIP بنجاح!');
    } catch (err) {
      console.error('Failed to generate zip:', err);
      // Fallback to text bundle if zip generation fails
      handleDownloadAllText();
    } finally {
      setIsZipping(false);
      setTimeout(() => setDownloadSuccessMessage(null), 4000);
    }
  };

  const handleDownloadSingleFile = (file: KotlinFile) => {
    const dataUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(file.content)}`;
    triggerDataDownload(dataUrl, file.filename);
  };

  const handleDownloadAllText = () => {
    let combined = `=====================================================\n`;
    combined += `FF TOUCH SENSITIVITY - ALL KOTLIN / GRADLE / XML FILES\n`;
    combined += `=====================================================\n\n`;

    KOTLIN_PROJECT_FILES.forEach((f) => {
      combined += `-----------------------------------------------------\n`;
      combined += `FILE: ${f.path}\n`;
      combined += `-----------------------------------------------------\n\n`;
      combined += f.content + `\n\n`;
    });

    const dataUrl = `data:text/plain;charset=utf-8,${encodeURIComponent(combined)}`;
    triggerDataDownload(dataUrl, 'FFTouchSensitivity_AllCodeBundle.txt');
    setDownloadSuccessMessage('تم تنزيل حزمة الكود الموحدة (TXT)!');
    setTimeout(() => setDownloadSuccessMessage(null), 4000);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner with Multiple Download Options */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col gap-4 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white uppercase font-mono">ملفات المشروع لتطبيق أندرويد (Kotlin & Android Studio)</h2>
              <p className="text-xs text-slate-400">
                مشروع كامل جاهز للفتح والتجميع المباشر في Android Studio بحزمة Jetpack Compose
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex-1 md:flex-initial px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs font-mono transition-all shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer"
            >
              <FolderArchive className="w-4 h-4" />
              <span>{isZipping ? 'جاري التجميع...' : 'تنزيل المشروع (.ZIP)'}</span>
            </button>

            <button
              onClick={handleDownloadAllText}
              className="flex-1 md:flex-initial px-4 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs font-mono transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>تنزيل كافة الكود (.TXT)</span>
            </button>

            <button
              onClick={handleCopyAllProjectCode}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs font-mono transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {allCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{allCopied ? 'تم نسخ الكل!' : 'نسخ كافة الكود'}</span>
            </button>
          </div>
        </div>

        {downloadSuccessMessage && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-4 py-2.5 rounded-xl text-xs font-mono flex items-center gap-2 animate-pulse">
            <Check className="w-4 h-4 shrink-0" />
            <span>{downloadSuccessMessage}</span>
          </div>
        )}

        {/* Browser / Iframe Download Help Banner */}
        <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3 text-xs text-slate-300 flex items-start gap-2.5">
          <HelpCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold text-amber-300">طرق الوصول للملفات في حالة قيود المعاينة:</p>
            <p className="text-slate-400 leading-relaxed">
              إذا منع متصفحك أو إطار المعاينة تنزيل ZIP التلقائي، يمكنك الضغط على <strong>"تنزيل كافة الكود (.TXT)"</strong> أو نسخ الملفات فردياً. كما يمكنك التصدير المباشر لـ <strong>GitHub</strong> أو تنزيل الـ ZIP عبر القائمة العلوية لمنصة AI Studio (Export / Download).
            </p>
          </div>
        </div>
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* File Selector Sidebar */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-1">
          <h3 className="text-xs font-bold text-slate-400 font-mono uppercase px-3 py-2 border-b border-slate-800/80 mb-2 flex items-center justify-between">
            <span>ملفات المشروع ({KOTLIN_PROJECT_FILES.length})</span>
            <FileCode className="w-3.5 h-3.5 text-cyan-400" />
          </h3>

          <div className="space-y-1 max-h-[500px] overflow-y-auto pr-1">
            {KOTLIN_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;

              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-cyan-500/10 border border-cyan-500/40 text-cyan-400 font-bold'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <span className="truncate">{file.filename}</span>
                  <FileCode className="w-3.5 h-3.5 shrink-0 opacity-60" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Viewer Panel */}
        <div className="lg:col-span-3 bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
          {/* Code Header */}
          <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 font-mono text-xs">
            <div className="flex items-center gap-2 text-slate-300 min-w-0">
              <Terminal className="w-4 h-4 text-cyan-400 shrink-0" />
              <span className="text-cyan-400 font-bold">{selectedFile.filename}</span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-500 text-[11px] truncate max-w-xs">{selectedFile.path}</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleDownloadSingleFile(selectedFile)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-mono flex items-center gap-1.5 transition-all cursor-pointer"
                title="تنزيل هذا الملف فقط"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>تحميل الملف</span>
              </button>

              <button
                onClick={handleCopyCode}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-mono flex items-center gap-1.5 transition-all cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
              </button>
            </div>
          </div>

          {/* Code Display */}
          <pre className="p-4 text-xs font-mono text-slate-300 overflow-x-auto max-h-[500px] leading-relaxed bg-slate-950 select-all">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};

