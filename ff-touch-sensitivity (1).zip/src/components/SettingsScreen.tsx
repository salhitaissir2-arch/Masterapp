import React, { useState } from 'react';
import { SensitivitySettings } from '../types';
import { sounds } from '../utils/audio';
import { Settings, Smartphone, Palette, Shield, Info, Volume2, Vibrate, Power, History, ExternalLink, FileText, CheckCircle2 } from 'lucide-react';

interface SettingsScreenProps {
  settings: SensitivitySettings;
  onUpdateSettings: (newSettings: Partial<SensitivitySettings>) => void;
  onOpenPermissionModal: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onUpdateSettings,
  onOpenPermissionModal,
}) => {
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);

  const handleToggle = (key: keyof SensitivitySettings) => {
    const updated = !settings[key];
    onUpdateSettings({ [key]: updated });
    sounds.playClick(settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);
  };

  const handleThemeChange = (theme: 'dark' | 'oled' | 'cyberpunk') => {
    onUpdateSettings({ theme });
    sounds.playClick(settings.soundEnabled);
    sounds.triggerHaptic(settings.hapticEnabled);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white uppercase font-mono">App Settings</h2>
            <p className="text-xs text-slate-400">Manage preferences, performance, and appearance</p>
          </div>
        </div>
      </div>

      {/* General Settings */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white uppercase font-mono flex items-center gap-2 border-b border-slate-800 pb-2">
          <Smartphone className="w-4 h-4 text-cyan-400" />
          <span>General</span>
        </h3>

        <div className="space-y-3 divide-y divide-slate-800/60">
          <div className="flex items-center justify-between pt-2">
            <div>
              <p className="text-xs font-bold text-white flex items-center gap-2">
                <Power className="w-3.5 h-3.5 text-slate-400" />
                <span>Start on boot</span>
              </p>
              <p className="text-[11px] text-slate-400">Automatically launch controller service when device powers on</p>
            </div>
            <input
              type="checkbox"
              checked={settings.startOnBoot}
              onChange={() => handleToggle('startOnBoot')}
              className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-3">
            <div>
              <p className="text-xs font-bold text-white flex items-center gap-2">
                <History className="w-3.5 h-3.5 text-slate-400" />
                <span>Remember last profile</span>
              </p>
              <p className="text-[11px] text-slate-400">Restore last active sensitivity preset on launch</p>
            </div>
            <input
              type="checkbox"
              checked={settings.rememberLastProfile}
              onChange={() => handleToggle('rememberLastProfile')}
              className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-3">
            <div>
              <p className="text-xs font-bold text-white flex items-center gap-2">
                <Vibrate className="w-3.5 h-3.5 text-slate-400" />
                <span>Haptic feedback</span>
              </p>
              <p className="text-[11px] text-slate-400">Vibrate device on slider adjustments and button clicks</p>
            </div>
            <input
              type="checkbox"
              checked={settings.hapticEnabled}
              onChange={() => handleToggle('hapticEnabled')}
              className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-3">
            <div>
              <p className="text-xs font-bold text-white flex items-center gap-2">
                <Volume2 className="w-3.5 h-3.5 text-slate-400" />
                <span>UI Sound effects</span>
              </p>
              <p className="text-[11px] text-slate-400">Play tactile audio feedback when modifying sliders</p>
            </div>
            <input
              type="checkbox"
              checked={settings.soundEnabled}
              onChange={() => handleToggle('soundEnabled')}
              className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Appearance Settings */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white uppercase font-mono flex items-center gap-2 border-b border-slate-800 pb-2">
          <Palette className="w-4 h-4 text-cyan-400" />
          <span>Appearance Theme</span>
        </h3>

        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => handleThemeChange('dark')}
            className={`p-3 rounded-xl border text-center transition-all ${
              settings.theme === 'dark'
                ? 'bg-cyan-500/10 border-cyan-500 text-white font-bold'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <span className="text-xs font-mono">Gaming Dark</span>
          </button>

          <button
            onClick={() => handleThemeChange('oled')}
            className={`p-3 rounded-xl border text-center transition-all ${
              settings.theme === 'oled'
                ? 'bg-cyan-500/10 border-cyan-500 text-white font-bold'
                : 'bg-black border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <span className="text-xs font-mono">OLED Black</span>
          </button>

          <button
            onClick={() => handleThemeChange('cyberpunk')}
            className={`p-3 rounded-xl border text-center transition-all ${
              settings.theme === 'cyberpunk'
                ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400 font-bold'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <span className="text-xs font-mono">Cyberpunk</span>
          </button>
        </div>
      </div>

      {/* Permissions Center */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 className="text-sm font-bold text-white uppercase font-mono flex items-center gap-2">
          <Shield className="w-4 h-4 text-cyan-400" />
          <span>Permissions & Security</span>
        </h3>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-white">Display Over Other Apps (Overlay)</p>
            <p className="text-[11px] text-slate-400">Required to render the floating quick-adjust widget</p>
          </div>
          <button
            onClick={onOpenPermissionModal}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 font-mono text-xs font-bold border border-slate-700"
          >
            Manage
          </button>
        </div>
      </div>

      {/* About Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 className="text-sm font-bold text-white uppercase font-mono flex items-center gap-2">
          <Info className="w-4 h-4 text-cyan-400" />
          <span>About App</span>
        </h3>

        <div className="space-y-2 text-xs font-mono text-slate-400">
          <div className="flex justify-between border-b border-slate-800/80 pb-2">
            <span>App Version:</span>
            <span className="text-white font-bold">v2.4.0 (Build 2026.08)</span>
          </div>
          <div className="flex justify-between border-b border-slate-800/80 pb-2 pt-1">
            <span>Target Platform:</span>
            <span className="text-cyan-400 font-bold">Android 14 (API 34) + Jetpack Compose</span>
          </div>
          <div className="flex justify-between border-b border-slate-800/80 pb-2 pt-1">
            <span>Fair Play Status:</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              100% Anti-Cheat Safe
            </span>
          </div>
        </div>

        <div className="pt-2 flex items-center justify-between text-xs font-mono">
          <button
            onClick={() => setShowPrivacyPolicy(true)}
            className="text-cyan-400 hover:underline flex items-center gap-1"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Privacy Policy</span>
          </button>
          <span className="text-slate-500">Developed for Mobile Gamers</span>
        </div>
      </div>

      {/* Privacy Policy Modal */}
      {showPrivacyPolicy && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl animate-scale-up">
            <h3 className="text-base font-bold text-white font-mono flex items-center gap-2">
              <FileText className="w-5 h-5 text-cyan-400" />
              <span>Privacy & Compliance Statement</span>
            </h3>

            <div className="text-xs text-slate-300 font-mono leading-relaxed space-y-3 max-h-60 overflow-y-auto pr-2">
              <p>
                <strong>1. Zero Data Collection:</strong> FF Touch Sensitivity operates 100% locally on your device. We do not collect, transmit, or store personal identifiers, device telemetry, or gaming statistics.
              </p>
              <p>
                <strong>2. Game Integrity Assurance:</strong> This application complies with Google Play policies and gaming fair play standards. It does NOT modify APK binaries, inject code into memory, or circumvent game rules.
              </p>
              <p>
                <strong>3. Permissions Usage:</strong> The Display Over Other Apps permission is strictly used to display the quick overlay widget.
              </p>
            </div>

            <button
              onClick={() => setShowPrivacyPolicy(false)}
              className="w-full py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-mono font-bold text-xs shadow-lg"
            >
              CLOSE
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
