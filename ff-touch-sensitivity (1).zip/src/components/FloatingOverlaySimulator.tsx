import React, { useState } from 'react';
import { SensitivitySettings } from '../types';
import { sounds } from '../utils/audio';
import { Layers, Move, Eye, EyeOff, Sliders, CheckCircle2, ShieldCheck, X, Zap } from 'lucide-react';

interface FloatingOverlaySimulatorProps {
  settings: SensitivitySettings;
  onUpdateHorizontal: (val: number) => void;
  onUpdateVertical: (val: number) => void;
  onApplySettings: () => void;
  onToggleOverlay: (enabled: boolean) => void;
  onOpenPermissionModal: () => void;
}

export const FloatingOverlaySimulator: React.FC<FloatingOverlaySimulatorProps> = ({
  settings,
  onUpdateHorizontal,
  onUpdateVertical,
  onApplySettings,
  onToggleOverlay,
  onOpenPermissionModal,
}) => {
  // Simulator floating widget state
  const [isOverlayExpanded, setIsOverlayExpanded] = useState(false);
  const [position, setPosition] = useState({ x: 30, y: 120 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const handleToggle = () => {
    if (!settings.overlayEnabled) {
      onOpenPermissionModal();
    } else {
      onToggleOverlay(false);
    }
  };

  // Dragging floating widget handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPosition({
      x: Math.max(10, Math.min(window.innerWidth - 200, e.clientX - dragOffset.x)),
      y: Math.max(10, Math.min(window.innerHeight - 200, e.clientY - dragOffset.y)),
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div
      className="space-y-6 animate-fade-in"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white uppercase font-mono">In-Game Floating Overlay</h2>
            <p className="text-xs text-slate-400">
              Quick-adjust panel accessible over Free Fire without leaving the game
            </p>
          </div>
        </div>

        <button
          onClick={handleToggle}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs font-mono transition-all shadow-lg flex items-center gap-2 ${
            settings.overlayEnabled
              ? 'bg-emerald-500 text-slate-950 shadow-emerald-500/20'
              : 'bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700'
          }`}
        >
          {settings.overlayEnabled ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
          <span>{settings.overlayEnabled ? 'OVERLAY ACTIVE' : 'ENABLE OVERLAY'}</span>
        </button>
      </div>

      {/* Live In-Game Simulation Sandbox */}
      <div className="relative bg-slate-950 border border-slate-800 rounded-2xl h-[420px] overflow-hidden shadow-2xl flex flex-col justify-between p-4">
        {/* Mock Game HUD Background */}
        <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#06b6d4_1px,transparent_1px)] [background-size:16px_16px] flex items-center justify-center">
          <div className="text-center font-mono text-slate-700 text-sm select-none">
            [ SIMULATED GAME HUD AREA ]<br />
            (Free Fire Battleground Screen)
          </div>
        </div>

        {/* Top Game Bar */}
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 border-b border-slate-900 pb-2 z-0">
          <span>ALIVE: 48</span>
          <span>KILLS: 3</span>
          <span>PING: 24ms</span>
        </div>

        {/* DRAGGABLE FLOATING WIDGET (Prompt Requirement #9) */}
        {settings.overlayEnabled ? (
          <div
            style={{ left: `${position.x}px`, top: `${position.y}px` }}
            className="absolute z-30 transition-shadow select-none"
          >
            {!isOverlayExpanded ? (
              // Collapsed Pill Badge: "FF TOUCH"
              <div
                onMouseDown={handleMouseDown}
                onClick={() => {
                  if (!isDragging) {
                    setIsOverlayExpanded(true);
                    sounds.playClick(settings.soundEnabled);
                  }
                }}
                className="cursor-move bg-slate-900/95 hover:bg-slate-900 border-2 border-cyan-400 text-cyan-400 px-3 py-1.5 rounded-full font-mono font-black text-xs shadow-2xl flex items-center gap-2 animate-bounce hover:animate-none active:scale-95"
              >
                <Move className="w-3.5 h-3.5 text-slate-400" />
                <span className="tracking-wider">FF TOUCH</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
            ) : (
              // Expanded Floating Quick Adjustment Panel (Prompt Requirement #9)
              <div className="bg-slate-900/95 border border-cyan-500/50 rounded-2xl p-4 w-64 shadow-2xl backdrop-blur-md space-y-3 animate-scale-up">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-black font-mono text-white">FF TOUCH OVERLAY</span>
                  </div>
                  <button
                    onClick={() => setIsOverlayExpanded(false)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-2 text-xs font-mono">
                  <div className="flex justify-between text-slate-300">
                    <span>Horizontal:</span>
                    <span className="text-cyan-400 font-bold">{Math.round(settings.horizontalSensitivity)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="200"
                    value={settings.horizontalSensitivity}
                    onChange={(e) => onUpdateHorizontal(Number(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded appearance-none cursor-pointer accent-cyan-400"
                  />

                  <div className="flex justify-between text-slate-300 pt-1">
                    <span>Vertical:</span>
                    <span className="text-cyan-400 font-bold">{Math.round(settings.verticalSensitivity)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="200"
                    value={settings.verticalSensitivity}
                    onChange={(e) => onUpdateVertical(Number(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => {
                      onApplySettings();
                      sounds.playSuccess(settings.soundEnabled);
                    }}
                    className="w-1/2 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono text-xs font-bold shadow-md"
                  >
                    Apply
                  </button>
                  <button
                    onClick={() => setIsOverlayExpanded(false)}
                    className="w-1/2 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-bold"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center space-y-3">
            <Layers className="w-10 h-10 text-slate-700" />
            <p className="text-xs text-slate-500 font-mono max-w-sm">
              Overlay is currently disabled. Enable Overlay to test the draggable floating control widget.
            </p>
          </div>
        )}

        {/* Bottom Game Controls Placeholder */}
        <div className="flex justify-between items-center text-[10px] font-mono text-slate-600 border-t border-slate-900 pt-2 z-0">
          <span>[ JOYSTICK AREA ]</span>
          <span>[ SHOOT BUTTON ]</span>
          <span>[ SCOPE BUTTON ]</span>
        </div>
      </div>

      {/* Safety Compliance Statement */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 text-xs space-y-2">
        <div className="flex items-center gap-2 text-emerald-400 font-bold font-mono">
          <ShieldCheck className="w-4 h-4" />
          <span>Android Overlay Safety Standard</span>
        </div>
        <p className="text-slate-400 leading-relaxed text-[11px]">
          The floating assistant uses Android’s official <code className="text-cyan-400">SYSTEM_ALERT_WINDOW</code> API. It operates purely as an external HUD layer, without reading memory, injecting code, or interfering with Free Fire anti-cheat mechanisms.
        </p>
      </div>
    </div>
  );
};
