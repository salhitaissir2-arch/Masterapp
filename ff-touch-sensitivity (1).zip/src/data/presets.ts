import { Preset } from '../types';

export const QUICK_PRESETS: Preset[] = [
  {
    id: 'default',
    name: 'Default',
    horizontalSensitivity: 100,
    verticalSensitivity: 100,
    description: 'Standard 1:1 raw touch baseline response.',
    tag: 'Balanced 1:1',
    recommendedFor: 'Casual gaming & standard navigation'
  },
  {
    id: 'balanced',
    name: 'Balanced',
    horizontalSensitivity: 120,
    verticalSensitivity: 100,
    description: 'Optimal for smooth 360° camera panning with stable vertical recoil.',
    tag: 'Recommended',
    recommendedFor: 'Close to medium-range spray control'
  },
  {
    id: 'fast_aim',
    name: 'Fast Aim',
    horizontalSensitivity: 150,
    verticalSensitivity: 110,
    description: 'High horizontal speed for quick target switching & flick shots.',
    tag: 'Aggressive',
    recommendedFor: 'Fast 1v1 close combat & quick scoping'
  },
  {
    id: 'precision',
    name: 'Precision',
    horizontalSensitivity: 90,
    verticalSensitivity: 80,
    description: 'Lower sensitivity for steady sniper aiming & fine adjustments.',
    tag: 'Control',
    recommendedFor: 'Long-range snipers & high-magnification scopes'
  },
  {
    id: 'headshot_boost',
    name: 'Headshot Drag',
    horizontalSensitivity: 140,
    verticalSensitivity: 160,
    description: 'Vertical bias for effortless upward drag-shots to lock on target head.',
    tag: 'Drag Shot',
    recommendedFor: 'Free Fire drag-headshot technique'
  }
];
